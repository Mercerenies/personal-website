
random :: RandomGenerator -> (Int, RandomGenerator)
random g = {- Some magic... -}
