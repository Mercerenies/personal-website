
multiples_of_three = set(range(0, 1000, 3))
multiples_of_five = set(range(0, 1000, 5))
all_multiples = multiples_of_three | multiples_of_five
print(sum(all_multiples))
