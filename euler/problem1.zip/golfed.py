
print(sum(i*(not i%3*i%5)for i in range(1000)))
