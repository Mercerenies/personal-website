
import Data.List

main :: IO ()
main = print $ sum ([3,6..999] `union` [5,10..999])
